import React from "react";

const SectionTitle = () => {
  return (
    <div>
      <h2 className="font-josef text-[38px] font-bold text-heading mb-3">
        Featured Products
      </h2>
    </div>
  );
};

export default SectionTitle;
