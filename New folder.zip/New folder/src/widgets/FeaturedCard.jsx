import React from "react";
import { AiOutlineShoppingCart } from "react-icons/ai";
import { GiSelfLove } from "react-icons/gi";
import { Link } from "react-router-dom";
import "./featuredCard.css";

const FeaturedCard = () => {
  return (
    <div className="shadow-lg featCard__wrapper">
      <div className="p-3 bg-[#F7F7F7]">
        <div className="featCard__icons flex gap-1 items-center">
          <Link
            to="/"
            className=" hover:bg-[#EEEFFB] duration-500 p-1 rounded-full text-[#1DB4E7] hover:text-[#2F1AC4]"
          >
            <AiOutlineShoppingCart className="" />
          </Link>
          <Link
            to="/"
            className=" hover:bg-[#EEEFFB] duration-500 p-1 rounded-full text-[#1DB4E7] hover:text-[#2F1AC4]"
          >
            <GiSelfLove />
          </Link>
          <Link
            to="/"
            className=" hover:bg-[#EEEFFB] duration-500 p-1 rounded-full text-[#1DB4E7] hover:text-[#2F1AC4]"
          >
            <AiOutlineShoppingCart className="" />
          </Link>
        </div>

        <img
          src="https://res.cloudinary.com/dygolqxi7/image/upload/v1682554171/myshop%28furniture%29/image_1_pnpqvr.png"
          alt=""
          className="mx-auto my-2 max-w-[110px] h-[130px]"
        />

        <button className="featCard__btn bg-[#08D15F] text-white fotn-josef text-[12px] px-4 py-1 rounded capitalize">
          Buy now
        </button>
      </div>

      <div className="py-5 ">
        <h5 className="text-primary font-semibold capitalize mb-1 featCard__text">
          Cantilever chair
        </h5>

        <div className="center gap-1 mb-1">
          <span className="h-1 w-4 bg-red-500 rounded-lg"></span>
          <span className="h-1 w-4 bg-red-500 rounded-lg"></span>
          <span className="h-1 w-4 bg-red-500 rounded-lg"></span>
        </div>

        <p className="text-heading font-josef mb-1 featCard__text">
          Code-Y5678
        </p>
        <p className="text-heading font-josef featCard__text">$56.00</p>
      </div>
    </div>
  );
};

export default FeaturedCard;
