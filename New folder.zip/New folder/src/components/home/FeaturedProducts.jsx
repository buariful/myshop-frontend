import React from "react";
import SectionTitle from "../../widgets/SectionTitle";
import FeaturedCard from "../../widgets/FeaturedCard";

const FeaturedProducts = () => {
  return (
    <>
      <SectionTitle />
      <div className="container px-2">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          <FeaturedCard />
          <FeaturedCard />
          <FeaturedCard />
          <FeaturedCard />
          <FeaturedCard />
          <FeaturedCard />
        </div>
      </div>
    </>
  );
};

export default FeaturedProducts;
