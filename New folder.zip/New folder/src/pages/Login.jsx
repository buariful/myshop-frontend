import React from "react";

const Login = () => {
  return <>lo gin</>;
};

export default Login;
