import React from "react";
import FeaturedProducts from "../components/home/FeaturedProducts";

const Home = () => {
  return (
    <>
      <FeaturedProducts />
    </>
  );
};

export default Home;
